package com.example.downloadmanager

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var files by mutableStateOf(emptyList<FileItem>())
    private var hasPermission by mutableStateOf(false)

    private val readPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        hasPermission = hasReadAccess()
        if (hasPermission) {
            loadDownloads()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                0xFFFFFFFF.toInt(),
                0xFFFFFFFF.toInt()
            ),
            navigationBarStyle = SystemBarStyle.light(
                0xFFFFFFFF.toInt(),
                0xFFFFFFFF.toInt()
            )
        )

        hasPermission = hasReadAccess()
        if (hasPermission) {
            loadDownloads()
        }

        setContent {
            MaterialTheme {
                Surface {
                    DownloadsScreen(
                        hasPermission = hasPermission,
                        files = files,
                        onRequestPermission = { requestAccess() },
                        onRefresh = { loadDownloads() },
                        onOpenFile = { openFile(it) }
                    )
                }
            }
        }
    }

    private fun hasReadAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            readPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun loadDownloads() {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val listedFiles = downloadsDir
            ?.listFiles()
            ?.asSequence()
            ?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.map { file ->
                FileItem(
                    name = file.name,
                    absolutePath = file.absolutePath,
                    updatedAt = file.lastModified(),
                    sizeBytes = file.length()
                )
            }
            ?.toList()
            .orEmpty()

        files = listedFiles
    }

    private fun openFile(fileItem: FileItem) {
        val file = File(fileItem.absolutePath)
        if (!file.exists()) {
            Toast.makeText(this, "Filen finns inte längre.", Toast.LENGTH_SHORT).show()
            loadDownloads()
            return
        }

        val authority = "$packageName.fileprovider"
        val fileUri = FileProvider.getUriForFile(this, authority, file)
        val mimeType = getMimeType(file)

        val openIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileUri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(openIntent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Ingen app kan öppna filtypen.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getMimeType(file: File): String {
        val extension = file.extension.lowercase(Locale.getDefault())
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            ?: "application/octet-stream"
    }
}

data class FileItem(
    val name: String,
    val absolutePath: String,
    val updatedAt: Long,
    val sizeBytes: Long
)

@Composable
private fun DownloadsScreen(
    hasPermission: Boolean,
    files: List<FileItem>,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit,
    onOpenFile: (FileItem) -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                onRefresh()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Downloads",
            style = MaterialTheme.typography.headlineSmall
        )

        if (!hasPermission) {
            Text(text = "Ge filåtkomst för att visa dina nedladdade filer.")
            Button(onClick = onRequestPermission) {
                Text("Ge åtkomst")
            }
            return@Column
        }

        if (files.isEmpty()) {
            Text("Inga filer hittades.")
            return@Column
        }

        val latestFile = files.first()

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val buttonVerticalOffset = maxHeight * 0.25f

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 180.dp)
            ) {
                items(files) { file ->
                    FileRow(file = file, onOpenFile = onOpenFile)
                    HorizontalDivider()
                }
            }

            Button(
                onClick = { onOpenFile(latestFile) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(horizontal = 6.dp)
                    .offset(y = -buttonVerticalOffset),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ComposeColor(0xFF1565C0),
                    contentColor = ComposeColor.White
                ),
                border = BorderStroke(2.dp, ComposeColor(0xFF0D47A1))
            ) {
                Text(
                    text = "Öppna senaste: ${latestFile.name}",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun FileRow(file: FileItem, onOpenFile: (FileItem) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenFile(file) }
            .padding(vertical = 10.dp)
    ) {
        Text(
            text = file.name,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "${formatDate(file.updatedAt)}  •  ${formatSize(file.sizeBytes)}",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private fun formatDate(timestamp: Long): String {
    return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        .format(Date(timestamp))
}

private fun formatSize(sizeBytes: Long): String {
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024

    return when {
        sizeBytes >= gb -> String.format(Locale.getDefault(), "%.1f GB", sizeBytes / gb)
        sizeBytes >= mb -> String.format(Locale.getDefault(), "%.1f MB", sizeBytes / mb)
        sizeBytes >= kb -> String.format(Locale.getDefault(), "%.1f KB", sizeBytes / kb)
        else -> "$sizeBytes B"
    }
}
