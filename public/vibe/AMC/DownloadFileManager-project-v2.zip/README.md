# Download File Manager (Android)

En enkel Android-app som:

- startar i `Download`-mappen
- listar filer i kronologisk ordning (senaste överst)
- öppnar fil direkt när du trycker på den
- håller UI:t minimalistiskt

## Körning

1. Öppna projektet i Android Studio.
2. Låt Android Studio skapa/uppdatera Gradle Wrapper vid behov.
3. Kör appen på en Android-enhet.
4. Ge filåtkomst när appen frågar om det.

## Viktigt om behörighet

På Android 11+ används "All files access" för att läsa Download-mappen.
