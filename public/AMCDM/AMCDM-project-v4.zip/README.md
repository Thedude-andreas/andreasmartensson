# Download File Manager (Android)

En enkel Android-app som:

- startar i `Download`-mappen
- listar filer i kronologisk ordning (senaste överst)
- öppnar fil direkt när du trycker på den
- håller UI:t minimalistiskt
- har en stor tumvänlig knapp för att öppna senaste filen direkt
- respekterar systembar/insets (ingen overlap med klocka/notiser)

## Körning

1. Öppna projektet i Android Studio.
2. Låt Android Studio skapa/uppdatera Gradle Wrapper vid behov.
3. Kör appen på en Android-enhet.
4. Ge filåtkomst när appen frågar om det.

## Viktigt om behörighet

På Android 11+ används "All files access" för att läsa Download-mappen.

## Bygga signerad release-APK

Signerad release byggs med Gradle och keystore:

```bash
./gradlew :app:assembleRelease \
  -Pandroid.injected.signing.store.file=/absolut/sökväg/release-keystore.jks \
  -Pandroid.injected.signing.store.password=*** \
  -Pandroid.injected.signing.key.alias=*** \
  -Pandroid.injected.signing.key.password=***
```

Resultatet hamnar i:

- `app/build/outputs/apk/release/app-release.apk`

## Publicerad projektsida

Projektet publiceras i webbprojektet under:

- `https://andreasmartensson.com/vibe/AMC/`
