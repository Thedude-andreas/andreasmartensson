package com.example.downloadmanager

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private const val PREFS_NAME = "download_manager_prefs"
private const val KEY_FOLDER_URIS = "folder_uris"

class MainActivity : ComponentActivity() {

    private var files by mutableStateOf(emptyList<FileItem>())
    private var hasPermission by mutableStateOf(false)
    private var selectedFolderUris by mutableStateOf(emptyList<String>())

    private val readPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        loadFiles()
    }

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                val current = selectedFolderUris.toMutableSet()
                current.add(uri.toString())
                selectedFolderUris = current.toList()
                saveFolderUris(selectedFolderUris)
                loadFiles()
            } catch (_: SecurityException) {
                Toast.makeText(this, "Kunde inte spara mappåtkomst.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(0xFF0B1020.toInt()),
            navigationBarStyle = SystemBarStyle.dark(0xFF0B1020.toInt())
        )

        selectedFolderUris = loadFolderUris()
        loadFiles()

        setContent {
            MaterialTheme(colorScheme = appColorScheme) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    DownloadsScreen(
                        hasDownloadsPermission = hasPermission,
                        files = files,
                        selectedFolders = getSelectedFoldersForUi(),
                        onRequestPermission = { requestAccess() },
                        onRefresh = { loadFiles() },
                        onOpenFile = { openFile(it) },
                        onAddFolder = { folderPickerLauncher.launch(null) },
                        onRemoveFolder = { removeFolder(it) }
                    )
                }
            }
        }
    }

    private fun loadFiles() {
        hasPermission = hasReadAccess()

        val allFiles = mutableListOf<FileItem>()
        if (hasPermission) {
            allFiles += loadDownloadsFiles()
        }
        allFiles += loadCustomFolderFiles()

        files = allFiles.sortedByDescending { it.updatedAt }
    }

    private fun loadDownloadsFiles(): List<FileItem> {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return downloadsDir
            ?.listFiles()
            ?.asSequence()
            ?.filter { it.isFile }
            ?.map { file ->
                FileItem(
                    name = file.name,
                    absolutePath = file.absolutePath,
                    contentUri = null,
                    updatedAt = file.lastModified(),
                    sizeBytes = file.length(),
                    sourceLabel = "Downloads"
                )
            }
            ?.toList()
            .orEmpty()
    }

    private fun loadCustomFolderFiles(): List<FileItem> {
        return selectedFolderUris.flatMap { uriString ->
            val uri = Uri.parse(uriString)
            val tree = DocumentFile.fromTreeUri(this, uri) ?: return@flatMap emptyList()
            val source = tree.name ?: "Vald mapp"

            tree.listFiles()
                .filter { it.isFile }
                .map { doc ->
                    FileItem(
                        name = doc.name ?: "Okänd fil",
                        absolutePath = null,
                        contentUri = doc.uri,
                        updatedAt = doc.lastModified(),
                        sizeBytes = doc.length(),
                        sourceLabel = source
                    )
                }
        }
    }

    private fun hasReadAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            readPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun openFile(fileItem: FileItem) {
        val uri = if (fileItem.contentUri != null) {
            fileItem.contentUri
        } else {
            val path = fileItem.absolutePath ?: return
            val file = File(path)
            if (!file.exists()) {
                Toast.makeText(this, "Filen finns inte längre.", Toast.LENGTH_SHORT).show()
                loadFiles()
                return
            }
            FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        }

        val mimeType = getMimeType(fileItem, uri)
        val openIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(openIntent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Ingen app kan öppna filtypen.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getMimeType(fileItem: FileItem, uri: Uri): String {
        contentResolver.getType(uri)?.let { return it }

        val extension = fileItem.name.substringAfterLast('.', "")
            .lowercase(Locale.getDefault())
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            ?: "application/octet-stream"
    }

    private fun saveFolderUris(uris: List<String>) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_FOLDER_URIS, uris.toSet())
            .apply()
    }

    private fun loadFolderUris(): List<String> {
        val uris = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getStringSet(KEY_FOLDER_URIS, emptySet())
            .orEmpty()
        return uris.toList()
    }

    private fun removeFolder(uriString: String) {
        val uri = Uri.parse(uriString)
        try {
            contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Ignore if permission is already gone.
        }

        selectedFolderUris = selectedFolderUris.filterNot { it == uriString }
        saveFolderUris(selectedFolderUris)
        loadFiles()
    }

    private fun getSelectedFoldersForUi(): List<FolderItem> {
        return selectedFolderUris.map { uriString ->
            val name = DocumentFile.fromTreeUri(this, Uri.parse(uriString))?.name ?: "Vald mapp"
            FolderItem(uriString = uriString, displayName = name)
        }
    }
}

data class FileItem(
    val name: String,
    val absolutePath: String?,
    val contentUri: Uri?,
    val updatedAt: Long,
    val sizeBytes: Long,
    val sourceLabel: String
)

data class FolderItem(
    val uriString: String,
    val displayName: String
)

private val appColorScheme = darkColorScheme(
    primary = Color(0xFFF97316),
    onPrimary = Color(0xFF0B1020),
    background = Color(0xFF0B1020),
    onBackground = Color(0xFFECF1FF),
    surface = Color(0xFF121936),
    onSurface = Color(0xFFECF1FF),
    outline = Color(0x33FFFFFF)
)

@Composable
private fun DownloadsScreen(
    hasDownloadsPermission: Boolean,
    files: List<FileItem>,
    selectedFolders: List<FolderItem>,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit,
    onOpenFile: (FileItem) -> Unit,
    onAddFolder: () -> Unit,
    onRemoveFolder: (String) -> Unit
) {
    var showFolderDialog by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                onRefresh()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (showFolderDialog) {
        FolderSettingsDialog(
            selectedFolders = selectedFolders,
            onAddFolder = onAddFolder,
            onRemoveFolder = onRemoveFolder,
            onDismiss = { showFolderDialog = false }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF1B2D5C), Color(0xFF0B1020))
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filer",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground
                )
                TextButton(onClick = { showFolderDialog = true }) {
                    Text("Mappar")
                }
            }

            if (!hasDownloadsPermission) {
                Text(
                    text = "Ge filåtkomst om du vill visa Download-mappen. Valda mappar fungerar ändå.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)
                )
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Ge åtkomst")
                }
            }

            if (files.isEmpty()) {
                Text(
                    text = "Inga filer hittades.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)
                )
                return@Column
            }

            val latestFile = files.first()

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val buttonVerticalOffset = maxHeight * 0.25f

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 180.dp)
                ) {
                    items(files) { file ->
                        FileRow(file = file, onOpenFile = onOpenFile)
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.12f)
                        )
                    }
                }

                Button(
                    onClick = { onOpenFile(latestFile) },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(72.dp)
                        .padding(horizontal = 6.dp)
                        .offset(y = -buttonVerticalOffset),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    border = BorderStroke(2.dp, Color(0xFFE35D0A))
                ) {
                    Text(
                        text = "Öppna senaste: ${latestFile.name}",
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun FolderSettingsDialog(
    selectedFolders: List<FolderItem>,
    onAddFolder: () -> Unit,
    onRemoveFolder: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mappar") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Downloads är standard. Lägg till extra mappar om du vill.")
                Button(onClick = onAddFolder) {
                    Text("Lägg till mapp")
                }

                if (selectedFolders.isEmpty()) {
                    Text("Inga extra mappar valda.")
                } else {
                    selectedFolders.forEach { folder ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = folder.displayName,
                                modifier = Modifier.padding(end = 8.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            TextButton(onClick = { onRemoveFolder(folder.uriString) }) {
                                Text("Ta bort")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Klar")
            }
        }
    )
}

@Composable
private fun FileRow(file: FileItem, onOpenFile: (FileItem) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
                shape = RoundedCornerShape(12.dp)
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onOpenFile(file) }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            text = file.name,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "${formatDate(file.updatedAt)}  •  ${formatSize(file.sizeBytes)}  •  ${file.sourceLabel}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private fun formatDate(timestamp: Long): String {
    if (timestamp <= 0L) return "Okänd tid"
    return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        .format(Date(timestamp))
}

private fun formatSize(sizeBytes: Long): String {
    if (sizeBytes < 0L) return "-"

    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024

    return when {
        sizeBytes >= gb -> String.format(Locale.getDefault(), "%.1f GB", sizeBytes / gb)
        sizeBytes >= mb -> String.format(Locale.getDefault(), "%.1f MB", sizeBytes / mb)
        sizeBytes >= kb -> String.format(Locale.getDefault(), "%.1f KB", sizeBytes / kb)
        else -> "$sizeBytes B"
    }
}
